# MEISTERWERK 1.4.1 – GitHub Pages + Regressionstests

## Lokal prüfen
Voraussetzung: Node.js 20 oder neuer. Es werden keine npm-Abhängigkeiten benötigt.

```bash
npm run check
```

Der Befehl prüft Inline-JavaScript, Service Worker, Manifest, erforderliche Dateien und führt die Interaktions-/Persistenztests aus.

## Zusätzlicher Chromium-Browser-Test
Voraussetzung: Python 3.10+ und Chromium.

```bash
python -m pip install -r requirements-test.txt
python -m playwright install chromium
python tests/browser-smoke.py
```

Der Browser-Test rendert die App in Chromium, klickt die Desktop- und mobile Navigation, öffnet Lektionen, prüft Quiz-Feedback und Karteikarten und kontrolliert acht Viewport-Breiten. Für die isolierte HTML-Testumgebung wird `localStorage` kontrolliert simuliert; die Persistenz-/Neustartlogik wird zusätzlich durch `npm run check` getestet.

## Veröffentlichung über GitHub Pages
1. Ein GitHub-Repository (z. B. `meisterwerk`) erstellen.
2. Alle Dateien und Ordner aus diesem Paket in das Repository-Hauptverzeichnis laden; `index.html` muss dort liegen.
3. Repository → **Settings** → **Pages** → **Deploy from a branch** wählen.
4. Branch `main`, Ordner `/ (root)` wählen und speichern.
5. Die von GitHub angezeigte HTTPS-Adresse in Safari öffnen.
6. Auf dem iPhone: Teilen → **Zum Home-Bildschirm**.

## Grenzen
Dies bleibt ein Frontend-Prototyp. Es gibt keine Benutzerkonten, Cloud-Synchronisierung, Zahlungsabwicklung oder KI-Lerncoach. Lernstand wird pro Browser lokal gespeichert. Die Node-Tests prüfen App-Logik mit einem simulierten DOM; sie ersetzen keinen visuellen Test in Safari oder auf einem physischen iPhone.

## Inhaltsinventar (Stand dieses Pakets)
- 8 Lektionen in Teil II – Haarbiologie
- 40 selbst erstellte Übungsfragen insgesamt: 10 je Prüfungsteil
- 40 Karteikarten
- Die geforderten zwei eigenständigen Wissenstests für das Haarbiologie-Modul sind noch nicht als separate Testsets implementiert.
- Damit fehlen für das Zielmodul noch 30 zusätzliche Teil-II-Übungsfragen und zwei klar abgegrenzte Wissenstests.

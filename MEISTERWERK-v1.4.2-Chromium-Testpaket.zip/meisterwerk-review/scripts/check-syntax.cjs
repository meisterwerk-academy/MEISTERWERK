const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(match => match[1]);
if (scripts.length !== 1) throw new Error(`Erwartet wurde 1 Inline-Script, gefunden: ${scripts.length}`);
new vm.Script(scripts[0], { filename: 'index.html:inline-script' });
new vm.Script(fs.readFileSync(path.join(root, 'sw.js'), 'utf8'), { filename: 'sw.js' });
JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
for (const rel of ['index.html', 'sw.js', 'manifest.webmanifest', 'assets/icon.svg']) {
  if (!fs.existsSync(path.join(root, rel))) throw new Error(`Datei fehlt: ${rel}`);
}
console.log('BESTANDEN – Inline-JavaScript, Service Worker, Manifest und Projektdateien');
